import React, { useRef, useEffect, useState } from 'react';
import { Search, Star } from 'lucide-react';
import RobotModel from './components/RobotModel';
import TeamSection from './components/TeamSection';
import AboutSection from './components/AboutSection';
import ContactSection from './components/ContactSection';
import ParallaxBackground from './components/ParallaxBackground';

function App() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);
  
  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      // Calculate normalized coordinates for Spline
      // Spline uses coordinates from -1 to 1 for both x and y
      setMousePosition({
        x: (event.clientX / window.innerWidth) * 2 - 1,
        y: -((event.clientY / window.innerHeight) * 2 - 1) // Invert Y for 3D space
      });
      
      // Also send the mouse event directly to any spline-viewer elements
      const splineViewer = document.querySelector('spline-viewer') as any;
      if (splineViewer && splineViewer.runtime) {
        try {
          // This directly communicates with the Spline runtime
          splineViewer.runtime.setMousePosition(
            (event.clientX / window.innerWidth) * 2 - 1,
            -((event.clientY / window.innerHeight) * 2 - 1)
          );
        } catch (error) {
          // Ignore errors if runtime is not ready
        }
      }
    };
    
    const handleScroll = () => {
      setScrollY(window.scrollY);
      
      // Handle scroll animations
      const animatedElements = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right, .scale-in');
      
      animatedElements.forEach((element) => {
        const elementTop = element.getBoundingClientRect().top;
        const elementBottom = element.getBoundingClientRect().bottom;
        const isVisible = elementTop < window.innerHeight - 100 && elementBottom > 0;
        
        if (isVisible) {
          element.classList.add('active');
        }
      });
      
      // Handle staggered animations
      const staggerContainers = document.querySelectorAll('.stagger-container');
      
      staggerContainers.forEach((container) => {
        const containerTop = container.getBoundingClientRect().top;
        const isVisible = containerTop < window.innerHeight - 100;
        
        if (isVisible) {
          const items = container.querySelectorAll('.stagger-item');
          items.forEach((item, index) => {
            setTimeout(() => {
              item.classList.add('active');
            }, index * 100); // 100ms delay between each item
          });
        }
      });
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);
    
    // Initial check for elements already in view on page load
    setTimeout(handleScroll, 100);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    // Add Spline viewer script
    const script = document.createElement('script');
    script.type = 'module';
    script.src = 'https://unpkg.com/@splinetool/viewer@1.9.72/build/spline-viewer.js';
    script.async = true;
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Hero Section with Robot */}
      <section className="min-h-screen gradient-bg relative">
        <ParallaxBackground />
        
        {/* Navigation */}
        <nav className="flex justify-between items-center py-6 px-10 relative z-10">
          <div className="flex items-center">
            <Star className="h-8 w-8 text-blue-900 fill-blue-900" />
          </div>
          <div className="flex items-center space-x-12">
            <a href="#" className="text-blue-900 font-semibold text-lg nav-link">Home</a>
            <a href="#about" className="text-blue-900 font-semibold text-lg nav-link">About</a>
            <a href="#team" className="text-blue-900 font-semibold text-lg nav-link">Our Team</a>
            <a href="#contact" className="text-blue-900 font-semibold text-lg nav-link">Contact us</a>
            <Search className="h-6 w-6 text-blue-900 cursor-pointer" />
          </div>
        </nav>

        <div className="flex h-[calc(100vh-80px)]">
          {/* Left Content */}
          <div className="flex flex-col justify-center pl-10 w-1/2 relative z-10">
            <h1 
              className="text-6xl font-bold text-blue-900 mb-6 fade-in"
              style={{ transitionDelay: '0.2s' }}
            >
              Welcome to E-cell of SCSIT
            </h1>
            <p 
              className="text-xl text-gray-800 mb-10 max-w-xl fade-in"
              style={{ transitionDelay: '0.4s' }}
            >
              The Entrepreneurship Cell (E-Cell) of SCSIT has been nurturing and inspiring Entrepreneurs since 2024.
            </p>
            <div 
              className="flex space-x-4 fade-in"
              style={{ transitionDelay: '0.6s' }}
            >
              <button className="btn-primary px-8 py-3 rounded-full font-bold text-lg">Join Now</button>
              <button className="btn-secondary px-8 py-3 rounded-full font-bold text-lg">Learn More</button>
            </div>
          </div>
          
          {/* Right Side - Robot Model */}
          <div className="w-1/2 relative z-10">
            <div className="robot-container">
              <RobotModel mousePosition={mousePosition} />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="min-h-screen w-full py-20 gradient-bg relative">
        <ParallaxBackground />
        <div className="relative z-10">
          <AboutSection scrollY={scrollY} />
        </div>
      </section>

      {/* Team Section */}
      <section id="team" className="min-h-screen w-full py-20 gradient-bg relative">
        <ParallaxBackground />
        <div className="relative z-10">
          <TeamSection />
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="w-full relative">
        <ContactSection />
      </section>
    </div>
  );
}

export default App;