import React from 'react';
import { Lightbulb, Target, Users, TrendingUp, Award, Rocket } from 'lucide-react';

interface AboutSectionProps {
  scrollY?: number;
}

const AboutSection: React.FC<AboutSectionProps> = ({ scrollY = 0 }) => {
  return (
    <div className="container mx-auto px-4 py-20">
      <h2 className="text-6xl font-bold text-blue-900 text-center mb-16 relative fade-in">
        About Us
        <div className="absolute left-1/2 transform -translate-x-1/2 bottom-0 w-24 h-1 bg-blue-900"></div>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-20">
        <div 
          className="about-image rounded-3xl overflow-hidden shadow-2xl slide-in-left"
          style={{ 
            transform: `translateY(${scrollY * 0.05}px)` 
          }}
        >
          <img 
            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1742&q=80" 
            alt="E-cell team meeting" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div 
          className="flex flex-col justify-center slide-in-right"
          style={{ 
            transform: `translateY(${scrollY * 0.03}px)` 
          }}
        >
          <h3 className="text-3xl font-bold text-blue-900 mb-6">Our Mission</h3>
          <p className="text-xl text-gray-800 mb-8">
            The Entrepreneurship Cell (E-Cell) of SCSIT is a student-run organization dedicated to fostering the entrepreneurial spirit among students. We aim to create a platform where innovative ideas can flourish and transform into successful ventures.
          </p>
          <p className="text-xl text-gray-800">
            Founded in 2024, our E-Cell has quickly grown to become a hub for aspiring entrepreneurs, providing resources, mentorship, and networking opportunities to help students turn their ideas into reality.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20 stagger-container">
        <div className="bg-white rounded-3xl p-8 shadow-xl transform transition-all duration-300 hover:scale-105 stagger-item">
          <div className="bg-blue-100 p-4 rounded-full inline-block mb-6">
            <Lightbulb size={32} className="text-blue-900" />
          </div>
          <h4 className="text-2xl font-bold text-blue-900 mb-4">Innovation</h4>
          <p className="text-gray-700">
            We encourage creative thinking and innovative solutions to real-world problems, fostering a culture of innovation among students.
          </p>
        </div>
        
        <div className="bg-white rounded-3xl p-8 shadow-xl transform transition-all duration-300 hover:scale-105 stagger-item">
          <div className="bg-blue-100 p-4 rounded-full inline-block mb-6">
            <Target size={32} className="text-blue-900" />
          </div>
          <h4 className="text-2xl font-bold text-blue-900 mb-4">Mentorship</h4>
          <p className="text-gray-700">
            Our network of experienced mentors provides guidance and support to help students navigate the challenges of entrepreneurship.
          </p>
        </div>
        
        <div className="bg-white rounded-3xl p-8 shadow-xl transform transition-all duration-300 hover:scale-105 stagger-item">
          <div className="bg-blue-100 p-4 rounded-full inline-block mb-6">
            <Users size={32} className="text-blue-900" />
          </div>
          <h4 className="text-2xl font-bold text-blue-900 mb-4">Community</h4>
          <p className="text-gray-700">
            We build a strong community of like-minded individuals who collaborate, share ideas, and support each other's entrepreneurial journeys.
          </p>
        </div>
      </div>

      <div 
        className="bg-white rounded-3xl p-12 shadow-2xl scale-in"
        style={{ 
          transform: `translateY(${scrollY * 0.02}px) scale(${scrollY > 800 ? 1 : 0.95})`,
          opacity: scrollY > 800 ? 1 : 0.9,
          transition: 'transform 0.5s ease, opacity 0.5s ease'
        }}
      >
        <h3 className="text-3xl font-bold text-blue-900 text-center mb-12">What We Offer</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 stagger-container">
          <div className="text-center stagger-item">
            <div className="bg-blue-100 p-6 rounded-full inline-flex justify-center items-center mb-6 w-24 h-24">
              <TrendingUp size={40} className="text-blue-900" />
            </div>
            <h4 className="text-xl font-bold text-blue-900 mb-3">Startup Workshops</h4>
            <p className="text-gray-700">
              Regular workshops on business planning, marketing, finance, and other essential aspects of building a startup.
            </p>
          </div>
          
          <div className="text-center stagger-item">
            <div className="bg-blue-100 p-6 rounded-full inline-flex justify-center items-center mb-6 w-24 h-24">
              <Award size={40} className="text-blue-900" />
            </div>
            <h4 className="text-xl font-bold text-blue-900 mb-3">Competitions</h4>
            <p className="text-gray-700">
              Exciting competitions like hackathons, business plan contests, and pitch events with attractive prizes and recognition.
            </p>
          </div>
          
          <div className="text-center stagger-item">
            <div className="bg-blue-100 p-6 rounded-full inline-flex justify-center items-center mb-6 w-24 h-24">
              <Rocket size={40} className="text-blue-900" />
            </div>
            <h4 className="text-xl font-bold text-blue-900 mb-3">Incubation Support</h4>
            <p className="text-gray-700">
              Resources and guidance to help promising startups take their first steps, including access to funding opportunities.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutSection;