import React, { useEffect, useRef } from 'react';

const ParallaxBackground: React.FC = () => {
  const parallaxRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!parallaxRef.current) return;
      
      const shapes = parallaxRef.current.querySelectorAll('.shape');
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      
      shapes.forEach((shape, index) => {
        const speed = 1 + index * 0.5;
        const xOffset = (x - 0.5) * speed * 30;
        const yOffset = (y - 0.5) * speed * 30;
        
        (shape as HTMLElement).style.transform = `translate(${xOffset}px, ${yOffset}px)`;
      });
    };
    
    const handleScroll = () => {
      if (!parallaxRef.current) return;
      
      const scrollY = window.scrollY;
      const shapes = parallaxRef.current.querySelectorAll('.shape');
      
      shapes.forEach((shape, index) => {
        const speed = 0.1 + index * 0.05;
        const yOffset = scrollY * speed;
        
        const currentTransform = (shape as HTMLElement).style.transform;
        const translateRegex = /translate\(([^,]+),\s*([^)]+)\)/;
        
        if (translateRegex.test(currentTransform)) {
          const matches = currentTransform.match(translateRegex);
          if (matches && matches.length >= 3) {
            const xOffset = matches[1];
            (shape as HTMLElement).style.transform = `translate(${xOffset}, calc(${matches[2]} - ${yOffset}px))`;
          }
        } else {
          (shape as HTMLElement).style.transform = `translateY(-${yOffset}px)`;
        }
      });
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  
  return (
    <div ref={parallaxRef} className="parallax-bg">
      <div className="shape shape-1"></div>
      <div className="shape shape-2"></div>
      <div className="shape shape-3"></div>
      <div className="shape shape-4"></div>
    </div>
  );
};

export default ParallaxBackground;