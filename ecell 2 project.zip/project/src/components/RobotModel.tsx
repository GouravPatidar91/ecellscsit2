import React, { useEffect, useRef } from 'react';

interface RobotModelProps {
  mousePosition: { x: number; y: number };
}

export default function RobotModel({ mousePosition }: RobotModelProps) {
  const splineRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    // Function to handle when the Spline viewer is loaded
    const handleSplineLoad = () => {
      const viewer = splineRef.current;
      if (viewer) {
        // Access the Spline API when it's ready
        viewer.addEventListener('load', () => {
          console.log('Spline scene loaded');
        });
      }
    };

    // Wait for the component to mount and the viewer to be available
    const checkSplineViewer = setInterval(() => {
      const viewer = document.querySelector('spline-viewer') as HTMLElement;
      if (viewer) {
        splineRef.current = viewer;
        handleSplineLoad();
        clearInterval(checkSplineViewer);
      }
    }, 100);

    return () => {
      clearInterval(checkSplineViewer);
    };
  }, []);

  // Update the Spline scene when mouse position changes
  useEffect(() => {
    if (splineRef.current) {
      // The Spline viewer exposes an API to control the scene
      // We need to wait for the spline runtime to be available
      const splineRuntime = (splineRef.current as any).runtime;
      if (splineRuntime) {
        try {
          // Send mouse position to Spline
          splineRuntime.setMousePosition(mousePosition.x, mousePosition.y);
        } catch (error) {
          console.log('Spline runtime not fully initialized yet');
        }
      }
    }
  }, [mousePosition]);

  return (
    <div className="w-full h-full">
      <spline-viewer url="https://prod.spline.design/hq1DP7kj5ILO0V3k/scene.splinecode"></spline-viewer>
    </div>
  );
}