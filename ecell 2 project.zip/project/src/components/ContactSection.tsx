import React, { useEffect, useRef } from 'react';
import { Linkedin, Github, Instagram, Mail, MapPin, Phone, ExternalLink } from 'lucide-react';

const ContactSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;
      
      const rect = sectionRef.current.getBoundingClientRect();
      const isVisible = rect.top < window.innerHeight - 100;
      
      if (isVisible) {
        const items = sectionRef.current.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right, .scale-in');
        items.forEach((item, index) => {
          setTimeout(() => {
            item.classList.add('active');
          }, index * 100);
        });
        
        const staggerContainers = sectionRef.current.querySelectorAll('.stagger-container');
        staggerContainers.forEach((container) => {
          const staggerItems = container.querySelectorAll('.stagger-item');
          staggerItems.forEach((item, index) => {
            setTimeout(() => {
              item.classList.add('active');
            }, 300 + index * 100);
          });
        });
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    
    // Check on initial load
    setTimeout(handleScroll, 100);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  
  return (
    <div className="w-full bg-blue-900 text-white py-16" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <h2 className="text-5xl font-bold text-center mb-16 relative fade-in">
          Contact Us
          <div className="absolute left-1/2 transform -translate-x-1/2 bottom-0 w-24 h-1 bg-white"></div>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16">
          {/* Contact Information */}
          <div className="flex flex-col items-center md:items-start slide-in-left">
            <h3 className="text-2xl font-bold mb-6">Get In Touch</h3>
            
            <div className="flex items-center mb-4">
              <Mail className="mr-3 text-cyan-300" size={20} />
              <a href="mailto:ecell@scsit.org" className="hover:text-cyan-300 transition-colors">ecell@scsit.org</a>
            </div>
            
            <div className="flex items-center mb-4">
              <Phone className="mr-3 text-cyan-300" size={20} />
              <a href="tel:+911234567890" className="hover:text-cyan-300 transition-colors">+91 123 456 7890</a>
            </div>
            
            <div className="flex items-start mb-4">
              <MapPin className="mr-3 text-cyan-300 mt-1 flex-shrink-0" size={20} />
              <p>School of Computer Science & IT,<br />Devi Ahilya University,<br />Indore, Madhya Pradesh, 452001</p>
            </div>
          </div>
          
          {/* Social Media */}
          <div className="flex flex-col items-center fade-in" style={{ transitionDelay: '0.2s' }}>
            <h3 className="text-2xl font-bold mb-6">Connect With Us</h3>
            
            <div className="flex space-x-6 stagger-container">
              <a 
                href="https://linkedin.com/company/ecell-scsit" 
                target="_blank" 
                rel="noopener noreferrer"
                className="social-icon-link stagger-item"
              >
                <Linkedin size={28} />
              </a>
              
              <a 
                href="https://github.com/ecell-scsit" 
                target="_blank" 
                rel="noopener noreferrer"
                className="social-icon-link stagger-item"
              >
                <Github size={28} />
              </a>
              
              <a 
                href="https://instagram.com/ecell_scsit" 
                target="_blank" 
                rel="noopener noreferrer"
                className="social-icon-link stagger-item"
              >
                <Instagram size={28} />
              </a>
            </div>
            
            <p className="mt-6 text-center">
              Follow us on social media for updates<br />on events, workshops, and opportunities.
            </p>
          </div>
          
          {/* Quick Links */}
          <div className="flex flex-col items-center md:items-start slide-in-right">
            <h3 className="text-2xl font-bold mb-6">Quick Links</h3>
            
            <ul className="space-y-3 stagger-container">
              <li className="stagger-item">
                <a href="#" className="flex items-center hover:text-cyan-300 transition-colors">
                  <ExternalLink size={16} className="mr-2" />
                  Home
                </a>
              </li>
              <li className="stagger-item">
                <a href="#about" className="flex items-center hover:text-cyan-300 transition-colors">
                  <ExternalLink size={16} className="mr-2" />
                  About Us
                </a>
              </li>
              <li className="stagger-item">
                <a href="#team" className="flex items-center hover:text-cyan-300 transition-colors">
                  <ExternalLink size={16} className="mr-2" />
                  Our Team
                </a>
              </li>
              <li className="stagger-item">
                <a href="#" className="flex items-center hover:text-cyan-300 transition-colors">
                  <ExternalLink size={16} className="mr-2" />
                  Events
                </a>
              </li>
              <li className="stagger-item">
                <a href="#" className="flex items-center hover:text-cyan-300 transition-colors">
                  <ExternalLink size={16} className="mr-2" />
                  Resources
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Newsletter Subscription */}
        <div className="bg-blue-800 rounded-xl p-8 mb-16 max-w-4xl mx-auto scale-in">
          <h3 className="text-2xl font-bold mb-4 text-center">Subscribe to Our Newsletter</h3>
          <p className="text-center mb-6">Stay updated with the latest news, events, and opportunities from E-cell SCSIT.</p>
          
          <form className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="flex-grow px-4 py-3 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-cyan-300"
            />
            <button 
              type="submit" 
              className="bg-cyan-500 hover:bg-cyan-600 px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
        
        {/* Footer Bottom */}
        <div className="border-t border-blue-800 pt-8 flex flex-col md:flex-row justify-between items-center fade-in" style={{ transitionDelay: '0.4s' }}>
          <p>&copy; {new Date().getFullYear()} E-cell SCSIT. All rights reserved.</p>
          
          <div className="mt-4 md:mt-0">
            <a href="#" className="text-sm mr-6 hover:text-cyan-300 transition-colors">Privacy Policy</a>
            <a href="#" className="text-sm hover:text-cyan-300 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSection;